var express = require('express');
var app = express();
var redis = require('redis');
var client = redis.createClient(6379,'kegerator.jrbqwx.0001.use1.cache.amazonaws.com');
var bodyParser = require('body-parser');
var jsonParser = bodyParser.json();

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});

client.on('connect',function() {
	console.log('connected');
});

app.get('/', function (req, res) {
  res.sendFile(__dirname + '/dashboard.html');
});

app.get('/listAll', function(req,res) {
	var resultList;
	client.multi()
		.get('numBeerPoured')
		.get('volumeLastBeerPoured')
		.get('cumulativeVolumeBeerPoured')
		.exec(function(err,resultList) {
        		var response;
        		response = '{"numBeersPoured" : '+resultList[0]+', "volLastBeerPoured" : '+resultList[1]+', "cumVolBeerPoured" : '+resultList[2]+'}';
        		res.send(response);
	});
});

app.get('/beersPoured', function(req,res) {
	client.get('numBeerPoured', function(err,reply) {
		if (err) {
			console.log('error getting numBeerPoured');
		}
		else {
			console.log('got value of numBeerPoured');
			res.send(reply.toString());
		}
	});
});

app.get('/volLastBeer', function(req,res) {
	client.get('volumeLastBeerPoured', function(err,reply) {
		if (err) {
			console.log('error getting volumeLastBeerPoured');
		}
		else {
			console.log('got value of volumeLastBeerPoured');
			res.send(reply.toString());
		}
	});
});

app.get('/cumVolBeerPoured', function(req,res) {
        client.get('cumulativeVolumeBeerPoured', function(err,reply) {
                if (err) {
                        console.log('error getting cumVolumeBeerPoured');
                }
                else {
                        console.log('got value of cumVolumeBeerPoured');
                        res.send(reply.toString());
                }
        });
});

app.get('/latest',function(req,res) {
	client.zrevrange('jsondpts',0,0,function(err,member) {
		if (err) {
			res.send('error');
		}
		else {
			console.log('got the latest record on redis set: '+member);
			console.log('length of member record: '+member.length);
			var arr = member[0].split(",");
			console.log('length of array: '+arr.length);
			var x = arr[0];
			var y = arr[1];
			var x_arr = x.split(":");
			var y_arr = y.split(":");
			var data = "{\""+x_arr[0]+"\":"+x_arr[1]+",\""+y_arr[0]+"\":"+y_arr[1]+"}";
			res.send(data);
		}
	});
});

app.post('/incrementBeersPoured', jsonParser, function(req,res) {
	if (!req.body) {
		return res.sendStatus(400);
	}
	else {
		//there is a body
		console.log(req.body);
		client.incr('numBeerPoured', function(err,reply) {
			if (err) {
				console.log('error incrementing the number of beers poured');
				console.log(err);
			}
			else {
				console.log('success incrementing the number of beers poured');
				console.log('new value = '+reply.toString());
				res.sendStatus(200);
			}		
		});
	}
});

app.post('/updateVolumeLastBeerPoured', jsonParser, function(req,res) {
        if (!req.body) {
                return res.sendStatus(400);
        }
        else {
                //there is a body
                console.log(req.body);
                client.set('volumeLastBeerPoured', req.body.volume.toString(), function(err,reply) {
                        if (err) {
                                console.log('error setting the volume of last beer poured');
                                console.log(err);
                        }
                        else {
                                console.log('success setting the volume of last beer poured');
                                console.log('new value = '+reply.toString());
                                res.sendStatus(200);
                        }
                });
        }
});

app.post('/incrementCumVolBeerPoured', jsonParser, function(req,res) {
        if (!req.body) {
                return res.sendStatus(400);
        }
        else {
                //there is a body
                console.log(req.body);
                client.incrby('cumulativeVolumeBeerPoured', req.body.volume.toString(), function(err,reply) {
                        if (err) {
                                console.log('error incrementing the cum volume of beer');
                                console.log(err);
                        }
                        else {
                                console.log('success incrementing the cum volume of beer');
                                console.log('new value = '+reply.toString());
                                res.sendStatus(200);
                        }
                });
        }
});

app.post('/update', jsonParser, function(req,res) {
	if (!req.body) {
		//there is no body
		return res.sendStatus(400);
	}
	else {
		client.multi()
			.set('volumeLastBeerPoured',req.body.volume.toString())
			.incrby('cumulativeVolumeBeerPoured',req.body.volume)
			.exec(function(err,resultList) {
				if (!err) {
					res.sendStatus(200);
				}
			});
	}
});
var server = app.listen(80, function () {
  var host = server.address().address;
  var port = server.address().port;

  console.log('Example app listening at http://%s:%s', host, port);
});
