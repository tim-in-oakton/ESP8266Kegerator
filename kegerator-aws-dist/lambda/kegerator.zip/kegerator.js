var AWS = require('aws-sdk');
//var async = require('async');
var Client = require('node-rest-client').Client;
var client = new Client();

//var apiLoc = 'http://52.2.198.72';
var apiLoc = 'http://kegerator.squishybit.info';

exports.handler = function(event, context) {
    //console.log('Received event:', JSON.stringify(event, null, 2));
    var message = event.Records[0].Sns.Message;
    console.log('From SNS, raw message:', message);

    var obj = JSON.parse(message);
    console.log('sender = '+obj.sender);
    console.log('tap = '+ obj.tap);
    console.log('event = '+obj.event);
    console.log('ticks = '+obj.ticks);
    console.log('time = '+obj.time);
    console.log('version = '+obj.version);

    if (obj.event === 'Pour_started') {
        console.log('pour started');
        //update the numBeersPoured api
        // set content-type header and data as json in args parameter
        var args = {
          data: { test: "hello" },
          headers:{"Content-Type": "application/json"}
        };

        client.post(apiLoc+'/incrementBeersPoured', args, function(data,response) {
          // parsed response body as js object
          console.log('response from incrementBeersPoured api: '+data);
          context.succeed(data);
          //callback(null,data);
        });
    }
    else {
        //event is 'pour ended'
        console.log('pour ended');
        //update the volumeLastBeerPoured api

        console.log('updating redis with more beer = '+obj.ticks);
        var args = {
          data: { "volume" : obj.ticks},
          headers:{"Content-Type": "application/json"}
        };
        client.post(apiLoc+'/update',args,function(data,response) {
          console.log('response from update api: '+data);
          context.succeed(data);
          //callback(null,data);
        });
    }


  //   async.waterfall([
  //   	function(callback) {
	// 		     //read the current state of redis
  //          //through node rest api
  //          client.get(apiLoc+'/listAll',function(data,response) {
  //            console.log('current data from node api = '+data);
  //            callback(null,data);
  //          });
  //   	},
  //   	function(arg1, callback) {
  //     		// arg1 now equals data.Body
  //           console.log('arg1 = '+arg1);
  //           var currentData = JSON.parse(arg1);
  //           if (obj.event === 'Pour_started') {
  //               console.log('pour started');
  //               //update the numBeersPoured api
  //               // set content-type header and data as json in args parameter
  //               var args = {
  //                 data: { test: "hello" },
  //                 headers:{"Content-Type": "application/json"}
  //               };
  //
  //               client.post(apiLoc+'/incrementBeersPoured', args, function(data,response) {
  //                 // parsed response body as js object
  //                 console.log('response from incrementBeersPoured api: '+data);
  //                 callback(null,data);
  //               });
  //           }
  //           else {
  //               //event is 'pour ended'
  //               console.log('pour ended');
  //               //update the volumeLastBeerPoured api
  //
  //               console.log('updating redis with more beer = '+obj.ticks);
  //               var args = {
  //                 data: { "volume" : obj.ticks},
  //                 headers:{"Content-Type": "application/json"}
  //               };
  //               client.post(apiLoc+'/update',args,function(data,response) {
  //                 console.log('response from update api: '+data);
  //                 callback(null,data);
  //               });
  //           }
  //   	}
	//   ], function (err, result) {
  //   	// result now equals 'OK'
  //       console.log('ending');
  //
  //       if (err) {
	//          console.log('ending with an error');
  //          context.fail(err);
  //       }
  //       else {
	//          console.log('success');
  //          context.succeed(result);
  //       }
	// });
};
